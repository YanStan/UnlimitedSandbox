
using System.Collections.Generic;
using UnityEngine;

namespace Unlimited.DensityTest
{
    public struct DensityTouchedColumn
    {
        public int x;
        public int z;

        public float minY;
        public float maxY;

        public DensityTouchedColumn(
            int x,
            int z,
            float minY,
            float maxY)
        {
            this.x = x;
            this.z = z;
            this.minY = minY;
            this.maxY = maxY;
        }
    }

    public sealed class DensityDigResult
    {
        public bool Changed =>
            TouchedColumns.Count > 0;

        public readonly List<DensityTouchedColumn>
            TouchedColumns =
                new List<DensityTouchedColumn>();
    }

    public sealed class DensityDigOperation
    {
        private const float Epsilon = 0.000001f;

        private readonly DensitySurfaceField field;

        private readonly DensityWorldConfig config;

        public DensityDigOperation(
            DensitySurfaceField field,
            DensityWorldConfig config)
        {
            this.field = field;
            this.config = config;
        }

        public DensityDigResult DigSphere(
            Vector3 center,
            float radius)
        {
            var result = new DensityDigResult();

            if (radius <= 0f)
                return result;

            int minX = Mathf.Max(
                0,
                field.WorldToGridX(
                    center.x - radius - 1f
                )
            );

            int maxX = Mathf.Min(
                field.W - 1,
                field.WorldToGridX(
                    center.x + radius + 1f
                )
            );

            int minZ = Mathf.Max(
                0,
                field.WorldToGridZ(
                    center.z - radius - 1f
                )
            );

            int maxZ = Mathf.Min(
                field.D - 1,
                field.WorldToGridZ(
                    center.z + radius + 1f
                )
            );

            float radiusSq = radius * radius;

            for (int x = minX; x <= maxX; x++)
            {
                float cx = field.GridToWorldX(x);

                for (int z = minZ; z <= maxZ; z++)
                {
                    if (field.IsNoDigBorderColumn(x, z))
                        continue;

                    float cz = field.GridToWorldZ(z);

                    float dx = cx - center.x;

                    float dz = cz - center.z;

                    float distXZSq =
                        dx * dx + dz * dz;

                    if (distXZSq > radiusSq)
                        continue;

                    int index = field.IDX(x, z);

                    List<SurfacePoint> column =
                        field.surfaceCache[index];

                    if (column == null ||
                        column.Count == 0)
                    {
                        continue;
                    }

                    var existingIntervals =
                        DensitySolidIntervals
                            .ColumnToIntervals(column);

                    if (existingIntervals.Count == 0)
                        continue;

                    float maxVerticalCut =
                        Mathf.Sqrt(
                            Mathf.Max(
                                0f,
                                radiusSq - distXZSq
                            )
                        );

                    float cutBottom = field.ClampY(
                        center.y -
                        maxVerticalCut -
                        config.digExpandMargin
                    );

                    float cutTop = field.ClampY(
                        center.y +
                        maxVerticalCut +
                        config.digExpandMargin
                    );

                    if (cutTop <= cutBottom + Epsilon)
                        continue;

                    var carvedIntervals =
                        DensitySolidIntervals
                            .SubtractSpanFromIntervals(
                                existingIntervals,
                                cutBottom,
                                cutTop
                            );

                    carvedIntervals =
                        DensitySolidIntervals
                            .SanitizeIntervals(
                                carvedIntervals,
                                field,
                                config
                            );

                    if (!DensitySolidIntervals
                        .IntervalsDiffer(
                            existingIntervals,
                            carvedIntervals
                        ))
                    {
                        continue;
                    }

                    column.Clear();

                    foreach (DensitySolidInterval interval
                             in carvedIntervals)
                    {
                        DensityWallCuts.AddPoint(
                            field,
                            config,
                            x,
                            z,
                            interval.bottom,
                            SurfaceKind.Ceiling,
                            cx,
                            cz
                        );

                        DensityWallCuts.AddPoint(
                            field,
                            config,
                            x,
                            z,
                            interval.top,
                            SurfaceKind.Top,
                            cx,
                            cz
                        );
                    }

                    var cavitySlices =
                        DensitySolidIntervals
                            .CollectCavitySlices(
                                existingIntervals,
                                cutBottom,
                                cutTop,
                                config
                            );

                    foreach (DensitySolidInterval slice
                             in cavitySlices)
                    {
                        DensityWallCuts
                            .AddSphereWallCutBand(
                                field,
                                config,
                                x,
                                z,
                                center,
                                radius,
                                cx,
                                cz,
                                slice.bottom,
                                slice.top
                            );
                    }

                    DensityWallCuts.SortColumn(column);

                    result.TouchedColumns.Add(
                        new DensityTouchedColumn(
                            x,
                            z,
                            cutBottom,
                            cutTop
                        )
                    );
                }
            }

            return result;
        }
    }
}
