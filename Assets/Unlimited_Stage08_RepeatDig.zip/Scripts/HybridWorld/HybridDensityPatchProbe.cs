using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Mathematics;
using UnityEngine.InputSystem;
using Unlimited.DensityTest;

namespace Unlimited.HybridWorld
{
    // Read-only integration test: existing Density mesher, real MapMagic heights.
    public sealed class HybridDensityPatchProbe : MonoBehaviour
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install() { new GameObject("Hybrid Density Patch Probe").AddComponent<HybridDensityPatchProbe>(); }
        Terrain terrain;
        TerrainData data;
        bool[,] original;
        int hx, hz, holeResolution;
        float savedPixelError; int savedMaximumLOD; bool lodSaved;
        readonly List<Mesh> meshes = new List<Mesh>();
        GameObject patch;
        DensitySurfaceField activeField;
        DensityWorldConfig activeConfig;
        WorldChunkKey activeKey;
        int activeBaseY, activeTopY, digCount;
        Material material;
        Material originalTerrainMaterial, testTerrainMaterial;
        void Start() { Debug.Log("[HybridTerrainHole] READY: LMB converts and repeatedly digs one patch; F8 restores it"); }
        void Update()
        {
            if (patch && (!terrain || !terrain.isActiveAndEnabled || terrain.terrainData != data || data.holesResolution != holeResolution || !terrain.drawHeightmap)) Restore();
            bool preview = Keyboard.current != null && Keyboard.current.f8Key.wasPressedThisFrame;
            bool dig = Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame;
            if (preview && patch) { Restore(); return; }
            if (patch) { if (dig) RepeatDig(); return; }
            if (!preview && !dig) return;
            try {
                var cam = FindPlayerCamera();
                if (!cam) throw new Exception("No active camera found on PlayerController or in scene");
                Debug.Log($"[HybridTerrainHole] CAMERA: {cam.name}, position={cam.transform.position}");
                var p = cam.transform.position;
                if (!preview) {
                    if (!Physics.Raycast(cam.transform.position, cam.transform.forward, out var target, 12f) || !(target.collider is TerrainCollider)) return;
                    p = target.point;
                }
                var key = WorldCoordinates.DensityAt(new double3(p.x,0,p.z));
                var o = WorldCoordinates.DensityOrigin(key);
                Terrain best = null;
                foreach (var t in Terrain.activeTerrains) {
                    if (!t || !t.terrainData || !t.drawHeightmap) continue;
                    var a=t.GetPosition(); var d=t.terrainData;
                    if (o.x<a.x || o.z<a.z || o.x+16>a.x+d.size.x || o.z+16>a.z+d.size.z) continue;
                    if (!best || d.heightmapResolution>best.terrainData.heightmapResolution) best=t;
                }
                if (!best) throw new Exception("No loaded tile contains the patch");
                terrain=best; data=best.terrainData; holeResolution=data.holesResolution;
                var pos=best.GetPosition();
                float sx=holeResolution/data.size.x, sz=holeResolution/data.size.z;
                hx=Mathf.RoundToInt((float)(o.x-pos.x)*sx); hz=Mathf.RoundToInt((float)(o.z-pos.z)*sz);
                int w=Mathf.RoundToInt(16*sx), h=Mathf.RoundToInt(16*sz);
                if (Math.Abs(hx-(o.x-pos.x)*sx)>0.001 || Math.Abs(hz-(o.z-pos.z)*sz)>0.001 || Math.Abs(w-16*sx)>0.001 || Math.Abs(h-16*sz)>0.001) throw new Exception("Terrain hole grid does not align with 16 m patch");
                Debug.Log($"[HybridTerrainHole] TILE: resolution={data.heightmapResolution}, holes={holeResolution}, patch={w} x {h}");
                if (w<=0 || h<=0 || hx<0 || hz<0 || hx+w>holeResolution || hz+h>holeResolution) throw new Exception("Invalid hole bounds");
                var saved=data.GetHoles(hx,hz,w,h);
                foreach(bool solid in saved) if(!solid) throw new Exception("Existing hole in test area");
                if (!preview && (p.x-o.x<4 || p.x-o.x>12 || p.z-o.z<4 || p.z-o.z>12)) { Debug.Log("[HybridDig] Test brush must be at least 4 m from patch edge"); Restore(); return; }
                if (!TryBuild(key, preview ? (Vector3?)null : p)) throw new Exception("Missing heights");
                original=saved;
                originalTerrainMaterial=terrain.materialTemplate;
                if(!originalTerrainMaterial) throw new Exception("Terrain has no material template");
                string shaderName=originalTerrainMaterial.shader.name;
                if(shaderName != "Unlimited/Grass Rock Slope Blend" && shaderName != "Unlimited/TriplanarGrass")
                    throw new Exception("Unsupported terrain shader: "+shaderName);
                var holeShader=originalTerrainMaterial.shader;
                if(!holeShader.isSupported || holeShader.FindPropertyIndex("_HybridHoleEnabled") < 0 || !originalTerrainMaterial.HasProperty("_HybridHoleTexture"))
                    throw new Exception("Original shader missing hybrid properties: "+shaderName+". Reimport the shader in Assets/Materials and check shader compilation errors.");
                testTerrainMaterial=new Material(originalTerrainMaterial);
                Debug.Log($"[HybridTerrainHole] MATERIAL: {shaderName}; original shader, no Resources");
                testTerrainMaterial.SetFloat("_HybridHoleEnabled",1);
                testTerrainMaterial.SetVector("_HybridHoleRect",new Vector4(pos.x,pos.z,data.size.x,data.size.z));
                testTerrainMaterial.SetFloat("_HybridHoleResolution",holeResolution);
                savedPixelError=terrain.heightmapPixelError; savedMaximumLOD=terrain.heightmapMaximumLOD; lodSaved=true;
                terrain.heightmapPixelError=1; terrain.heightmapMaximumLOD=0;
                patch.SetActive(true);
                data.SetHoles(hx,hz,new bool[h,w]);
                terrain.Flush();
                testTerrainMaterial.SetTexture("_HybridHoleTexture",data.holesTexture);
                terrain.materialTemplate=testTerrainMaterial;
                foreach(bool solid in data.GetHoles(hx,hz,w,h)) if(solid) throw new Exception("Hole readback failed");
                Physics.SyncTransforms();
                var center=new Vector3((float)o.x+8, data.size.y+pos.y+100, (float)o.z+8);
                bool hit=false;
                foreach(var r in Physics.RaycastAll(center,Vector3.down,data.size.y+200)) {
                    if(r.collider.transform.IsChildOf(patch.transform)) hit=true;
                    if(r.collider is TerrainCollider) throw new Exception("Terrain collider still present inside hole: "+r.collider.name);
                }
                if(!hit && preview) throw new Exception("Density collider raycast failed");
                Debug.Log($"[HybridTerrainHole] PASS: {w} x {h} hole, density collider hit; F8 restores terrain");
            } catch(Exception e) { Restore(); Debug.LogError("[HybridTerrainHole] FAIL: "+e); }
        }
        void RepeatDig()
        {
            var cam=FindPlayerCamera();
            if(!cam || activeField==null) return;
            if(!Physics.Raycast(cam.transform.position,cam.transform.forward,out var hit,12f) || !hit.collider.transform.IsChildOf(patch.transform)) return;
            var p=hit.point-patch.transform.position;
            if(Mathf.Abs(p.x)>4 || Mathf.Abs(p.z)>4) { Debug.Log("[HybridDig] Keep brush center 4 m from patch edge"); return; }
            if(p.y<19) { Debug.Log("[HybridDig] Lower test boundary reached"); return; }
            var cache=activeField.surfaceCache;
            var backup=new List<SurfacePoint>[cache.Length];
            for(int i=0;i<cache.Length;i++) if(cache[i]!=null) backup[i]=new List<SurfacePoint>(cache[i]);
            GameObject next=null;
            var nextMeshes=new List<Mesh>();
            try {
                var result=new DensityDigOperation(activeField,activeConfig).DigSphere(p,3f);
                if(!result.Changed) return;
                next=new GameObject("Hybrid Density Patch");
                next.SetActive(false);
                next.transform.SetParent(transform,false);
                next.transform.position=patch.transform.position;
                BuildGeometry(activeField,activeKey,activeBaseY,activeTopY,next,nextMeshes);
                var old=patch;
                old.SetActive(false);
                next.SetActive(true);
                patch=next;
                Destroy(old);
                foreach(var m in meshes) if(m) Destroy(m);
                meshes.Clear(); meshes.AddRange(nextMeshes);
                Physics.SyncTransforms();
                Debug.Log($"[HybridDig] PASS: strike {++digCount}, changed columns {result.TouchedColumns.Count}");
            } catch(Exception e) {
                for(int i=0;i<cache.Length;i++) cache[i]=backup[i];
                if(next) Destroy(next);
                foreach(var m in nextMeshes) if(m) Destroy(m);
                Debug.LogError("[HybridDig] Rebuild failed; previous density retained: "+e);
            }
        }
        static Camera FindPlayerCamera()
        {
            foreach (var player in UnityEngine.Object.FindObjectsByType<global::PlayerController>(FindObjectsSortMode.None))
            {
                if (!player.isActiveAndEnabled) continue;
                foreach (var camera in player.GetComponentsInChildren<Camera>())
                    if (camera.isActiveAndEnabled) return camera;
            }
            if (Camera.main && Camera.main.isActiveAndEnabled) return Camera.main;
            foreach (var camera in Camera.allCameras)
                if (camera.isActiveAndEnabled && camera.cameraType == CameraType.Game) return camera;
            return null;
        }
        void Restore()
        {
            if(original!=null && data && data.holesResolution==holeResolution) data.SetHoles(hx,hz,original);
            original=null;
            if(lodSaved && terrain){terrain.heightmapPixelError=savedPixelError;terrain.heightmapMaximumLOD=savedMaximumLOD;} lodSaved=false;
            if(terrain && testTerrainMaterial && terrain.materialTemplate==testTerrainMaterial) terrain.materialTemplate=originalTerrainMaterial;
            if(testTerrainMaterial) Destroy(testTerrainMaterial);
            testTerrainMaterial=null; originalTerrainMaterial=null;
            if(patch) { patch.SetActive(false); Destroy(patch); }
            patch=null;
            foreach(var m in meshes) if(m) Destroy(m);
            meshes.Clear();
            if(material) Destroy(material); material=null;
            terrain=null; data=null; activeField=null; activeConfig=null; digCount=0;
        }
        void OnDisable() { Restore(); }
        static List<Vector3> Clip(List<Vector3> input,int axis,float bound,bool greater)
        {
            var output=new List<Vector3>();
            if(input.Count==0) return output;
            Vector3 a=input[input.Count-1];
            foreach(var b in input) {
                bool ia=greater?a[axis]>=bound:a[axis]<=bound;
                bool ib=greater?b[axis]>=bound:b[axis]<=bound;
                if(ia!=ib) { var v=Vector3.LerpUnclamped(a,b,(bound-a[axis])/(b[axis]-a[axis])); v[axis]=bound; output.Add(v); }
                if(ib) output.Add(b);
                a=b;
            }
            return output;
        }
        Mesh ClipAndStitch(Mesh source,double3 origin,int baseY,out Mesh seam)
        {
            seam=null;
            var vertices=new List<Vector3>(); var triangles=new List<int>();
            var map=new Dictionary<Vector3,int>();
            var input=source.vertices; var indices=source.triangles;
            var pos=terrain.GetPosition();
            float dx=data.size.x/holeResolution, dz=data.size.z/holeResolution;
            int w=Mathf.RoundToInt(16/dx), h=Mathf.RoundToInt(16/dz);
            bool On(float x,float b) => Mathf.Abs(x-b)<0.00001f;
            Vector3 Ground(Vector3 q) {
                bool vertical=On(q.x,-8)||On(q.x,8);
                bool horizontal=On(q.z,-8)||On(q.z,8);
                if(!vertical&&!horizontal)return q;
                if(vertical) {
                    q.x=q.x<0?-8:8;
                    int x=hx+(q.x<0?0:w);
                    float g=Mathf.Clamp((q.z+8)/dz,0,h);
                    int k=Mathf.Min(Mathf.FloorToInt(g),h-1);
                    q.y=Mathf.Lerp(data.GetHeight(x,hz+k),data.GetHeight(x,hz+k+1),g-k)+pos.y-baseY;
                } else {
                    q.z=q.z<0?-8:8;
                    int z=hz+(q.z<0?0:h);
                    float g=Mathf.Clamp((q.x+8)/dx,0,w);
                    int k=Mathf.Min(Mathf.FloorToInt(g),w-1);
                    q.y=Mathf.Lerp(data.GetHeight(hx+k,z),data.GetHeight(hx+k+1,z),g-k)+pos.y-baseY;
                }
                return q;
            }
            int Index(Vector3 q) {
                if(!map.TryGetValue(q,out int i)){i=vertices.Count;map.Add(q,i);vertices.Add(q);}return i;
            }
            void Tri(Vector3 a,Vector3 b,Vector3 c) {
                if(Vector3.Cross(b-a,c-a).sqrMagnitude<1e-12f)return;
                triangles.Add(Index(a));triangles.Add(Index(b));triangles.Add(Index(c));
            }
            for(int i=0;i<indices.Length;i+=3) {
                var poly=new List<Vector3>{input[indices[i]],input[indices[i+1]],input[indices[i+2]]};
                poly=Clip(poly,0,-8,true);poly=Clip(poly,0,8,false);poly=Clip(poly,2,-8,true);poly=Clip(poly,2,8,false);
                if(poly.Count<3)continue;
                var ring=new List<Vector3>(); bool boundary=false;
                for(int j=0;j<poly.Count;j++) {
                    var a=poly[j];var b=poly[(j+1)%poly.Count];
                    var snapped=Ground(a);ring.Add(snapped);
                    boundary|=On(a.x,-8)||On(a.x,8)||On(a.z,-8)||On(a.z,8);
                    bool vertical=(On(a.x,-8)&&On(b.x,-8))||(On(a.x,8)&&On(b.x,8));
                    bool horizontal=(On(a.z,-8)&&On(b.z,-8))||(On(a.z,8)&&On(b.z,8));
                    if(!vertical&&!horizontal)continue;
                    int axis=vertical?2:0;float step=vertical?dz:dx;int count=vertical?h:w;
                    float delta=b[axis]-a[axis];if(Mathf.Abs(delta)<1e-7f)continue;
                    var cuts=new List<float>();
                    for(int k=1;k<count;k++){float f=(-8+k*step-a[axis])/delta;if(f>0.000001f&&f<0.999999f)cuts.Add(f);}
                    cuts.Sort();foreach(float f in cuts)ring.Add(Ground(Vector3.LerpUnclamped(a,b,f)));
                }
                if(!boundary){for(int j=1;j+1<ring.Count;j++)Tri(ring[0],ring[j],ring[j+1]);continue;}
                Vector3 center=Vector3.zero;foreach(var q in poly)center+=q;center/=poly.Count;
                for(int j=0;j<ring.Count;j++)Tri(center,ring[j],ring[(j+1)%ring.Count]);
            }
            if(triangles.Count==0)return null;
            var mesh=new Mesh{indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};mesh.SetVertices(vertices);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
        }
        bool TryBuild(WorldChunkKey key, Vector3? digPoint)
        {
            const int pad=4, side=24;
            var origin=WorldCoordinates.DensityOrigin(key);
            var heights=new float[side,side];
            float low=float.PositiveInfinity, high=float.NegativeInfinity;
            for(int x=0;x<side;x++) for(int z=0;z<side;z++)
            {
                var a=terrain.GetPosition(); var size=data.size;
                float u=(float)((origin.x+x-pad-a.x)/size.x), v=(float)((origin.z+z-pad-a.z)/size.z);
                float h;
                if(u>=0 && u<=1 && v>=0 && v<=1) h=data.GetInterpolatedHeight(u,v)+a.y;
                else if(!TerrainHeightSource.TrySample(new double3(origin.x+x-pad,0,origin.z+z-pad),default,out h)) return false;
                if(float.IsNaN(h)||float.IsInfinity(h)) return false;
                heights[x,z]=h; low=Mathf.Min(low,h); high=Mathf.Max(high,h);
            }
            int baseY=Mathf.FloorToInt(low/16)*16-16;
            int topY=Mathf.CeilToInt(high/16)*16+16;
            Debug.Log($"[HybridDensityPatch] HEIGHTS: {low:F3} .. {high:F3}, base {baseY}, top {topY}");
            var config=GetComponent<DensityWorldConfig>(); if(!config) config=gameObject.AddComponent<DensityWorldConfig>();
            config.width=side; config.depth=side; config.height=topY-baseY+1; config.noDigBorderVoxels=0;
            var field=new DensitySurfaceField(config);
            for(int x=0;x<side;x++) for(int z=0;z<side;z++)
            {
                float wx=field.GridToWorldX(x), wz=field.GridToWorldZ(z);
                field.surfaceCache[field.IDX(x,z)]=new List<SurfacePoint>(2){
                    new SurfacePoint{y=0,kind=SurfaceKind.Ceiling,realX=wx,realZ=wz},
                    new SurfacePoint{y=heights[x,z]-baseY,kind=SurfaceKind.Top,realX=wx,realZ=wz}};
            }
            activeField=field; activeConfig=config; activeKey=key; activeBaseY=baseY; activeTopY=topY;
            if(digPoint.HasValue) {
                var p=digPoint.Value-new Vector3((float)origin.x+8,baseY,(float)origin.z+8);
                var result=new DensityDigOperation(field,config).DigSphere(p,3f);
                if(!result.Changed) throw new Exception("Brush did not change density");
                digCount=1; Debug.Log($"[HybridDig] Changed columns: {result.TouchedColumns.Count}");
            }
            patch=new GameObject("Hybrid Density Preview");
            patch.transform.SetParent(transform,false);
            patch.transform.position=new Vector3((float)origin.x+8,baseY,(float)origin.z+8);
            patch.SetActive(false);
            var shader=Shader.Find("Universal Render Pipeline/Lit");
            if(!shader) throw new Exception("URP Lit shader missing");
            material=new Material(shader); material.color=new Color(0.55f,0.35f,0.18f);
            return BuildGeometry(field,key,baseY,topY,patch,meshes);
        }
        bool BuildGeometry(DensitySurfaceField field, WorldChunkKey key, int baseY, int topY, GameObject root, List<Mesh> output)
        {
            const int pad=4;
            var origin=WorldCoordinates.DensityOrigin(key);
            int vertices=0, triangles=0, sections=0;
            using(var pipeline=new DensityMeshPipeline(field))
            {
                for(int y=16;y<topY-baseY;y+=16)
                {
                    Debug.Log($"[HybridDensityPatch] MESH: section y={y}");
                    Mesh mesh=pipeline.BuildChunkMesh(pad-2,y,pad-2,pad+18,y+16,pad+18);
                    if(!mesh) continue;
                    var clipped=ClipAndStitch(mesh,origin,baseY,out var seam);
                    Destroy(mesh);
                    mesh=clipped;
                    if(!mesh) continue;
                    output.Add(mesh);
                    {
                        foreach(var v in mesh.vertices) if(float.IsNaN(v.x)||float.IsNaN(v.y)||float.IsNaN(v.z)||float.IsInfinity(v.x)||float.IsInfinity(v.y)||float.IsInfinity(v.z)) throw new Exception("Non-finite vertex");
                        vertices+=mesh.vertexCount; triangles+=(int)mesh.GetIndexCount(0)/3; sections++;
                    var child=new GameObject("Density section "+y);
                        child.transform.SetParent(root.transform,false);
                        child.AddComponent<MeshFilter>().sharedMesh=mesh;
                        child.AddComponent<MeshRenderer>().sharedMaterial=material;
                        child.AddComponent<MeshCollider>().sharedMesh=mesh;
                        if(seam) {
                            output.Add(seam);
                            var closure=new GameObject("Visual seam closure");
                            closure.transform.SetParent(child.transform,false);
                            closure.AddComponent<MeshFilter>().sharedMesh=seam;
                            closure.AddComponent<MeshRenderer>().sharedMaterial=material;
                        }
                    }
                }
            }
            if(vertices==0||triangles==0) throw new Exception("No surface geometry generated");
            Debug.Log($"[HybridDensityPatch] PASS: 16 x 16 footprint, {sections} surface sections, {vertices} vertices, {triangles} triangles; preview mesh prepared");
            return true;
        }
    }
}
