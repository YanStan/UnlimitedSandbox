
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Unlimited.DensityTest
{
    public enum DensityBrushShape
    {
        [InspectorName("Hemisphere")] Hemisphere = 0,
        [InspectorName("Sphere")] Sphere = 2,
        [InspectorName("Smooth Cube")] SmoothCube = 1,
        [InspectorName("Sharp Cube")] SharpCube = 3
    }

    public sealed class DensityDigController : MonoBehaviour
    {
        [Header("References")]

        public DensityWorldController worldController;

        public Camera playerCamera;

        [Header("Digging")]

        public DensityBrushShape brushShape = DensityBrushShape.Hemisphere;

        [Min(0.1f)]
        public float maxDigDistance = 10f;

        [Range(0f, 1f)]
        public float digStrength = 0f;

        [Range(0f, 1f)]
        public float angleFactor = 0.25f;

        [Header("Debug")]

        public bool showDebugGizmos = true;

        public bool logDigHits = true;

        private DensityWorldConfig config;

        private DensitySurfaceField field;

        private DensityChunkTest chunkGenerator;

        private DensityChunkColliders chunkColliders;

        private DensityNormalSmoother normalSmoother;

        private DensityDigOperation digOperation;

        private DensityDirtySections dirtySections;

        private DensityBowlOperation currentBowl;
        private Bounds currentBox;

        private bool hasTarget;

        private bool canDig;

        private bool isDigging;

        private Vector3 hitPosition;

        private Vector3 hitNormal;

        private Vector3Int gridPosition;

        private Vector3Int chunkPosition;

        private void OnEnable()
        {
            Debug.Log("[DensityDig] Four Brushes FIX loaded: Hemisphere, Sphere, Smooth Cube, Sharp Cube", this);
        }

        private void UpdateBrushSelection()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;
            DensityBrushShape next = brushShape;
            if (keyboard.digit1Key.wasPressedThisFrame) next = DensityBrushShape.Hemisphere;
            else if (keyboard.digit2Key.wasPressedThisFrame) next = DensityBrushShape.Sphere;
            else if (keyboard.digit3Key.wasPressedThisFrame) next = DensityBrushShape.SmoothCube;
            else if (keyboard.digit4Key.wasPressedThisFrame) next = DensityBrushShape.SharpCube;
            if (next == brushShape) return;
            brushShape = next;
            Debug.Log($"[DensityDig] Brush: {brushShape}", this);
        }

        private void Update()
        {
            UpdateBrushSelection();
            hasTarget = false;

            canDig = false;

            if (isDigging)
                return;

            if (!InitializeReferences())
                return;

            if (!chunkGenerator.IsGenerationComplete)
                return;

            if (chunkColliders != null &&
                !chunkColliders.IsReady)
            {
                return;
            }

            UpdateDigTarget();

            if (!hasTarget || !canDig)
                return;

            if (Mouse.current == null)
                return;

            if (Mouse.current.leftButton.wasPressedThisFrame)
            {
                ProcessDig();
            }
        }

        private bool InitializeReferences()
        {
            if (worldController == null)
            {
                worldController =
                    FindFirstObjectByType<
                        DensityWorldController
                    >();
            }

            if (worldController == null)
                return false;

            if (playerCamera == null)
            {
                playerCamera =
                    GetComponentInChildren<Camera>();
            }

            if (playerCamera == null)
                return false;

            if (config == null)
            {
                config = worldController
                    .GetComponent<DensityWorldConfig>();
            }

            if (chunkGenerator == null)
            {
                chunkGenerator = worldController
                    .GetComponent<DensityChunkTest>();
            }

            if (chunkColliders == null)
            {
                chunkColliders = worldController
                    .GetComponent<DensityChunkColliders>();
            }

            if (normalSmoother == null)
            {
                normalSmoother = worldController
                    .GetComponent<DensityNormalSmoother>();
            }

            DensitySurfaceField currentField =
                worldController.SurfaceField;

            if (config == null ||
                currentField == null ||
                chunkGenerator == null)
            {
                return false;
            }

            if (field != currentField ||
                digOperation == null ||
                dirtySections == null)
            {
                field = currentField;

                digOperation =
                    new DensityDigOperation(
                        field,
                        config
                    );

                dirtySections =
                    new DensityDirtySections(
                        field,
                        config
                    );
            }

            return true;
        }

        private void UpdateDigTarget()
        {
            Ray ray = new Ray(
                playerCamera.transform.position,
                playerCamera.transform.forward
            );

            if (!Physics.Raycast(
                ray,
                out RaycastHit hit,
                maxDigDistance,
                Physics.DefaultRaycastLayers,
                QueryTriggerInteraction.Ignore))
            {
                return;
            }

            if (!hit.collider.transform.IsChildOf(
                worldController.transform))
            {
                return;
            }

            if (!hit.collider.gameObject.name.StartsWith(
                "DensityChunk_"))
            {
                return;
            }

            hasTarget = true;

            hitPosition = hit.point;

            hitNormal = hit.normal;

            Transform worldTransform =
                worldController.transform;

            Vector3 localHit =
                worldTransform.InverseTransformPoint(
                    hit.point
                );

            Vector3 localDirection =
                worldTransform.InverseTransformVector(
                    ray.direction
                ).normalized;

            int gridX =
                field.WorldToGridX(localHit.x);

            int gridY =
                Mathf.FloorToInt(localHit.y);

            int gridZ =
                field.WorldToGridZ(localHit.z);

            gridPosition = new Vector3Int(
                gridX,
                gridY,
                gridZ
            );

            chunkPosition = new Vector3Int(
                Mathf.FloorToInt(
                    gridX / (float)config.chunkSize
                ),

                Mathf.FloorToInt(
                    gridY / (float)config.sectionHeight
                ),

                Mathf.FloorToInt(
                    gridZ / (float)config.chunkSize
                )
            );

            currentBowl =
                DensityDigShape.ComputeBowl(
                    localHit,
                    localDirection,
                    config,
                    false,
                    digStrength,
                    angleFactor
                );

            if (brushShape == DensityBrushShape.Sphere)
            {
                currentBowl = new DensityBowlOperation
                {
                    center = localHit,
                    radius = 3f,
                    depth = 3f
                };
            }

            Vector3 normal = worldTransform.localToWorldMatrix.transpose
                .MultiplyVector(hit.normal).normalized;
            Vector3 axis = Vector3.up * Mathf.Sign(normal.y);
            Vector3 size = new Vector3(4f, 1f, 4f);
            if (Mathf.Abs(normal.x) >= Mathf.Abs(normal.y) &&
                Mathf.Abs(normal.x) >= Mathf.Abs(normal.z))
            {
                axis = Vector3.right * Mathf.Sign(normal.x);
                size = new Vector3(1f, 4f, 4f);
            }
            else if (Mathf.Abs(normal.z) > Mathf.Abs(normal.y))
            {
                axis = Vector3.forward * Mathf.Sign(normal.z);
                size = new Vector3(4f, 4f, 1f);
            }
            currentBox = new Bounds(localHit - axis * 0.5f, size);

            if (!field.InBounds(gridX, gridZ))
                return;

            if (gridY < 0 || gridY >= field.H)
                return;

            if (field.IsNoDigBorderColumn(
                gridX,
                gridZ))
            {
                return;
            }

            canDig = true;
        }

        private void ProcessDig()
        {
            if (isDigging)
                return;

            isDigging = true;

            var totalTimer =
                System.Diagnostics.Stopwatch.StartNew();

            try
            {
                dirtySections.Clear();

                var digTimer =
                    System.Diagnostics.Stopwatch.StartNew();

                DensityDigResult result =
                    brushShape == DensityBrushShape.SmoothCube
                        ? digOperation.DigBox(currentBox, 0.5f)
                        : brushShape == DensityBrushShape.SharpCube
                            ? digOperation.DigBox(currentBox)
                            : digOperation.DigSphere(currentBowl.center, currentBowl.radius);

                digTimer.Stop();

                if (!result.Changed)
                {
                    if (logDigHits)
                    {
                        Debug.Log(
                            "[DensityDig] No terrain changes"
                        );
                    }

                    return;
                }

                field.MarkBrushCells(result, brushShape == DensityBrushShape.SharpCube);
                dirtySections.MarkDigResult(result);

                List<Vector3Int> sections =
                    dirtySections.Consume();

                var rebuildTimer =
                    System.Diagnostics.Stopwatch.StartNew();

                chunkGenerator.RebuildSections(
                    sections
                );

                rebuildTimer.Stop();

                var normalsTimer =
                    System.Diagnostics.Stopwatch.StartNew();

                if (normalSmoother != null)
                {
                    normalSmoother.SmoothNormals();
                }

                normalsTimer.Stop();

                totalTimer.Stop();

                if (logDigHits)
                {
                    Debug.Log(
                        "[DensityDig] Dig completed\n" +

                        $"Hit position: {hitPosition}\n" +

                        $"Grid position: {gridPosition}\n" +

                        $"Chunk position: {chunkPosition}\n" +

                        (brushShape == DensityBrushShape.SmoothCube || brushShape == DensityBrushShape.SharpCube
                            ? $"Box center: {currentBox.center}\nBox size: {currentBox.size}\n"
                            : $"Sphere center: {currentBowl.center}\nDig radius: {currentBowl.radius:F2} m\nDig depth: {currentBowl.depth:F2} m\n") +

                        $"Changed columns: {result.TouchedColumns.Count}\n" +

                        $"Dirty sections: {sections.Count}\n" +

                        $"Dig operation: {digTimer.Elapsed.TotalMilliseconds:F2} ms\n" +

                        $"Mesh and collider rebuild: {rebuildTimer.Elapsed.TotalMilliseconds:F2} ms\n" +

                        $"Normal smoothing: {normalsTimer.Elapsed.TotalMilliseconds:F2} ms\n" +

                        $"Total dig time: {totalTimer.Elapsed.TotalMilliseconds:F2} ms"
                    );
                }
            }
            finally
            {
                isDigging = false;
            }
        }

        private void OnDrawGizmos()
        {
            if (!Application.isPlaying)
                return;

            if (!showDebugGizmos || !hasTarget)
                return;

            if (config == null ||
                worldController == null)
            {
                return;
            }

            Matrix4x4 previousMatrix =
                Gizmos.matrix;

            Gizmos.matrix =
                worldController.transform
                    .localToWorldMatrix;

            Gizmos.color = canDig ? Color.green : Color.red;

            if (brushShape == DensityBrushShape.SmoothCube ||
                brushShape == DensityBrushShape.SharpCube)
            {
                Gizmos.DrawWireCube(
                    currentBox.center,
                    currentBox.size
                );
            }
            else
            {
                Gizmos.DrawWireSphere(
                    currentBowl.center,
                    currentBowl.radius
                );
            }

            Gizmos.matrix = previousMatrix;

            Gizmos.color = Color.yellow;

            Gizmos.DrawSphere(
                hitPosition,
                0.08f
            );

            Gizmos.color = Color.cyan;

            Gizmos.DrawLine(
                hitPosition,
                hitPosition + hitNormal * 1.5f
            );

            if (playerCamera != null)
            {
                Gizmos.color = Color.white;

                Gizmos.DrawLine(
                    playerCamera.transform.position,
                    hitPosition
                );
            }
        }
    }
}
